--
-- PostgreSQL database dump
--

\restrict oZ5wb9b8GAK9I7iExRacf3phCgZLBNJKFi6zqs1wS1N3UxfKRFywTdxFUljjU7G

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: customer_sessions; Type: TABLE; Schema: public; Owner: hdos
--

CREATE TABLE public.customer_sessions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    shop_id character varying NOT NULL,
    customer_id character varying,
    session_token character varying(64) NOT NULL,
    device_fingerprint character varying(64),
    device_type character varying(50),
    os character varying(50),
    browser character varying(50),
    user_agent text,
    screen_width integer,
    screen_height integer,
    language character varying(10),
    ip_address character varying(45),
    city character varying(100),
    started_at timestamp without time zone DEFAULT now(),
    last_activity_at timestamp without time zone DEFAULT now(),
    ended_at timestamp without time zone
);


ALTER TABLE public.customer_sessions OWNER TO hdos;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: hdos
--

CREATE TABLE public.customers (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    shop_id character varying NOT NULL,
    name character varying(200) NOT NULL,
    phone character varying(20) NOT NULL,
    email character varying(255),
    first_visit timestamp without time zone DEFAULT now(),
    last_visit timestamp without time zone DEFAULT now(),
    last_order_at timestamp without time zone,
    total_visits integer DEFAULT 1 NOT NULL,
    total_orders integer DEFAULT 0 NOT NULL,
    total_spent numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    avg_bill numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    device_type character varying(50),
    os character varying(50),
    browser character varying(50),
    screen_width integer,
    screen_height integer,
    language character varying(10),
    ip_address character varying(45),
    city character varying(100),
    has_consent boolean DEFAULT false NOT NULL,
    last_offer_sent timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.customers OWNER TO hdos;

--
-- Name: delivery_charge_reasons; Type: TABLE; Schema: public; Owner: hdos
--

CREATE TABLE public.delivery_charge_reasons (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    shop_id character varying NOT NULL,
    reason character varying(255) NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.delivery_charge_reasons OWNER TO hdos;

--
-- Name: menu_categories; Type: TABLE; Schema: public; Owner: hdos
--

CREATE TABLE public.menu_categories (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    shop_id character varying NOT NULL,
    name character varying(100) NOT NULL,
    order_no integer DEFAULT 0 NOT NULL,
    is_visible boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    delivery_charge numeric(10,2) DEFAULT '0'::numeric,
    delivery_charge_label character varying(100)
);


ALTER TABLE public.menu_categories OWNER TO hdos;

--
-- Name: menu_items; Type: TABLE; Schema: public; Owner: hdos
--

CREATE TABLE public.menu_items (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    shop_id character varying NOT NULL,
    category_id character varying,
    name character varying(200) NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    image text,
    is_available boolean DEFAULT true NOT NULL,
    is_veg boolean DEFAULT false,
    is_bestseller boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.menu_items OWNER TO hdos;

--
-- Name: offers; Type: TABLE; Schema: public; Owner: hdos
--

CREATE TABLE public.offers (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    shop_id character varying NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    discount_type character varying(20) DEFAULT 'percentage'::character varying NOT NULL,
    discount_value numeric(10,2) NOT NULL,
    min_visits integer DEFAULT 0,
    min_order_amount numeric(10,2),
    expiry_date timestamp without time zone,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.offers OWNER TO hdos;

--
-- Name: order_items; Type: TABLE; Schema: public; Owner: hdos
--

CREATE TABLE public.order_items (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    order_id character varying NOT NULL,
    item_id character varying NOT NULL,
    item_name character varying(200) NOT NULL,
    price numeric(10,2) NOT NULL,
    quantity integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.order_items OWNER TO hdos;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: hdos
--

CREATE TABLE public.orders (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    shop_id character varying NOT NULL,
    customer_id character varying,
    order_number character varying(20),
    table_qr character varying(50),
    delivery_address text,
    subtotal numeric(10,2) NOT NULL,
    discount_amount numeric(10,2) DEFAULT '0'::numeric,
    delivery_charge numeric(10,2) DEFAULT '0'::numeric,
    total_amount numeric(10,2) NOT NULL,
    status character varying(30) DEFAULT 'pending_payment'::character varying NOT NULL,
    payment_mode character varying(30),
    payment_reference character varying(100),
    payment_verified_at timestamp without time zone,
    payment_verified_by character varying,
    bill_number character varying(20),
    bill_url text,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.orders OWNER TO hdos;

--
-- Name: page_visits; Type: TABLE; Schema: public; Owner: hdos
--

CREATE TABLE public.page_visits (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    page character varying(200) NOT NULL,
    shop_id character varying,
    os character varying(50),
    browser character varying(50),
    device_type character varying(20),
    user_agent text,
    ip_hash character varying(64),
    city character varying(100),
    visited_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.page_visits OWNER TO hdos;

--
-- Name: profiles; Type: TABLE; Schema: public; Owner: hdos
--

CREATE TABLE public.profiles (
    id character varying NOT NULL,
    user_id character varying NOT NULL,
    role character varying(20) DEFAULT 'shop_admin'::character varying NOT NULL,
    shop_id character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.profiles OWNER TO hdos;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: hdos
--

CREATE TABLE public.sessions (
    sid character varying NOT NULL,
    sess jsonb NOT NULL,
    expire timestamp without time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO hdos;

--
-- Name: shop_sections; Type: TABLE; Schema: public; Owner: hdos
--

CREATE TABLE public.shop_sections (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    shop_id character varying NOT NULL,
    section_type character varying(50) NOT NULL,
    title character varying(200),
    description text,
    image_url text,
    order_no integer DEFAULT 0 NOT NULL,
    is_visible boolean DEFAULT true NOT NULL,
    settings jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.shop_sections OWNER TO hdos;

--
-- Name: shop_themes; Type: TABLE; Schema: public; Owner: hdos
--

CREATE TABLE public.shop_themes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    primary_color character varying(7) DEFAULT '#2563eb'::character varying NOT NULL,
    secondary_color character varying(7) DEFAULT '#f59e0b'::character varying NOT NULL,
    font_family character varying(100) DEFAULT 'Plus Jakarta Sans'::character varying NOT NULL,
    button_style character varying(20) DEFAULT 'rounded'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.shop_themes OWNER TO hdos;

--
-- Name: shops; Type: TABLE; Schema: public; Owner: hdos
--

CREATE TABLE public.shops (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    slug character varying(100) NOT NULL,
    shop_name character varying(200) NOT NULL,
    logo text,
    banner text,
    whatsapp_number character varying(20),
    super_admin_whatsapp character varying(20),
    address text,
    about text,
    theme_id character varying,
    admin_password character varying(100) DEFAULT 'shop123'::character varying NOT NULL,
    upi_id character varying(255),
    upi_qr_image text,
    gst_number character varying(20),
    delivery_charge numeric(10,2) DEFAULT '0'::numeric,
    allowed_pin_codes text DEFAULT '495118'::text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    delivery_charge_reason character varying(255),
    free_delivery_threshold numeric(10,2)
);


ALTER TABLE public.shops OWNER TO hdos;

--
-- Name: store_availability; Type: TABLE; Schema: public; Owner: hdos
--

CREATE TABLE public.store_availability (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    shop_id character varying NOT NULL,
    opening_time character varying(5) DEFAULT '09:00'::character varying NOT NULL,
    closing_time character varying(5) DEFAULT '22:00'::character varying NOT NULL,
    timezone character varying(50) DEFAULT 'Asia/Kolkata'::character varying NOT NULL,
    manual_override character varying(20) DEFAULT 'none'::character varying NOT NULL,
    override_reason text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.store_availability OWNER TO hdos;

--
-- Name: store_holidays; Type: TABLE; Schema: public; Owner: hdos
--

CREATE TABLE public.store_holidays (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    shop_id character varying NOT NULL,
    holiday_date character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.store_holidays OWNER TO hdos;

--
-- Name: user_behaviors; Type: TABLE; Schema: public; Owner: hdos
--

CREATE TABLE public.user_behaviors (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    shop_id character varying NOT NULL,
    customer_id character varying,
    session_id character varying,
    event_type character varying(50) NOT NULL,
    item_id character varying,
    page character varying(100),
    time_spent integer,
    metadata jsonb,
    occurred_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_behaviors OWNER TO hdos;

--
-- Name: users; Type: TABLE; Schema: public; Owner: hdos
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    email character varying,
    first_name character varying,
    last_name character varying,
    profile_image_url character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO hdos;

--
-- Data for Name: customer_sessions; Type: TABLE DATA; Schema: public; Owner: hdos
--

COPY public.customer_sessions (id, shop_id, customer_id, session_token, device_fingerprint, device_type, os, browser, user_agent, screen_width, screen_height, language, ip_address, city, started_at, last_activity_at, ended_at) FROM stdin;
16f90ba7-66de-41e8-a6be-da3905ecfb83	62c19d2c-eaa8-4d06-84d0-b02153132768	\N	d8ad4b656814fbe7d62a0751da46127bdfe8c861e1afae857821c5dd63cd51db	91c29c740b473fd33394839942a1689a	desktop	Windows 10	Firefox	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1536	864	en-US	110.224.161.250	\N	2026-02-06 03:13:22.471626	2026-02-07 00:12:56.818	\N
a806f239-9ae2-4bd8-93bd-7d66f8fb04b6	dd3cce5c-df8e-41ef-af93-4212b1a03e83	\N	06ab0f45274772179f516d5c238b8976eb4345bf9d84dc6871b428446cc7ff37	6f97e11e1f4b70a159c0872e02abaab6	desktop	Windows 10	Firefox	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1536	864	en-US	110.224.161.250	\N	2026-02-06 02:44:10.706448	2026-02-07 07:47:43.809	\N
52ee9eab-818f-4807-a0d5-186eb01ca3a2	abb2d289-d13b-4a97-b73f-b4f63161c766	\N	ea50596e758bdad3eba192ce878c29570f537f961e91904c2b1dd3b80b10a017	d0e2c474b06968c592c3bb8abd420c0a	desktop	Windows 10	Firefox	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1536	864	en-US	110.224.161.250	\N	2026-02-06 01:45:10.178755	2026-02-06 03:19:35.026	\N
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: hdos
--

COPY public.customers (id, shop_id, name, phone, email, first_visit, last_visit, last_order_at, total_visits, total_orders, total_spent, avg_bill, device_type, os, browser, screen_width, screen_height, language, ip_address, city, has_consent, last_offer_sent, created_at) FROM stdin;
191f8706-bae1-407c-917b-6040c1dd17a2	abb2d289-d13b-4a97-b73f-b4f63161c766	miss	8789868764	\N	2026-02-06 01:57:31.61822	2026-02-06 02:22:34.564	\N	3	0	0.00	0.00	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	2026-02-06 01:57:31.61822
01346c2d-367d-4e4d-9f48-49d5ad3ce29b	62c19d2c-eaa8-4d06-84d0-b02153132768	miss manu	+9283938408	\N	2026-02-06 03:34:44.97196	2026-02-06 23:33:31.974	\N	4	0	0.00	0.00	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	2026-02-06 03:34:44.97196
\.


--
-- Data for Name: delivery_charge_reasons; Type: TABLE DATA; Schema: public; Owner: hdos
--

COPY public.delivery_charge_reasons (id, shop_id, reason, is_default, is_active, created_at) FROM stdin;
5ba683a1-06fc-4a5d-b22e-cfad83981881	62c19d2c-eaa8-4d06-84d0-b02153132768	kilomeeter ke hisab se	t	t	2026-02-06 03:22:29.197312
\.


--
-- Data for Name: menu_categories; Type: TABLE DATA; Schema: public; Owner: hdos
--

COPY public.menu_categories (id, shop_id, name, order_no, is_visible, created_at, delivery_charge, delivery_charge_label) FROM stdin;
e07ced0e-a745-4226-8752-13d0e7c4352c	abb2d289-d13b-4a97-b73f-b4f63161c766	Beverages	4	t	2026-02-06 01:43:58.173983	0.00	\N
f8a07de2-bd38-4dc5-ae18-d38c3a1c6a45	abb2d289-d13b-4a97-b73f-b4f63161c766	Snacks	6	t	2026-02-06 01:43:58.176504	0.00	\N
88f8de26-9542-4e92-9910-c909fb374e27	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Starters	0	t	2026-02-06 02:41:16.912782	0.00	\N
9fb210a2-f28c-4cab-8901-736f3fc3cab5	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Main Course	1	t	2026-02-06 02:41:16.914459	0.00	\N
7eeaa9c9-dd30-4cc6-b0aa-0e97b94da263	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Breads	2	t	2026-02-06 02:41:16.915616	0.00	\N
19cd8eda-09c7-4224-b107-c4c23f829032	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Rice	3	t	2026-02-06 02:41:16.916727	0.00	\N
57d967ff-bfbe-41ed-b957-f6682039a35f	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Beverages	4	t	2026-02-06 02:41:16.917855	0.00	\N
c31888d8-62e7-4a19-85ed-3b51b5931e2d	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Desserts	5	t	2026-02-06 02:41:16.919009	0.00	\N
b4d90236-6c15-4154-ac3a-77f86fbd5c1f	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Snacks	6	t	2026-02-06 02:41:16.920103	0.00	\N
cc6f87c7-6691-476d-bf8c-cc9aa1caebb3	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Combo Meals	7	t	2026-02-06 02:41:16.921334	0.00	\N
8cc60129-fd68-45f2-a56b-ae2a143d1b56	62c19d2c-eaa8-4d06-84d0-b02153132768	Starters	0	t	2026-02-06 03:10:41.112332	0.00	\N
2326326b-c4fe-4050-950d-c05826950a20	62c19d2c-eaa8-4d06-84d0-b02153132768	Main Course	1	t	2026-02-06 03:10:41.114111	0.00	\N
8b920aa2-6732-4b0e-b815-360057286a7b	62c19d2c-eaa8-4d06-84d0-b02153132768	Breads	2	t	2026-02-06 03:10:41.115344	0.00	\N
2b789316-b346-4ad0-8f09-c7571a309968	62c19d2c-eaa8-4d06-84d0-b02153132768	Rice	3	t	2026-02-06 03:10:41.116592	0.00	\N
7308ad15-816a-45fe-87d4-cd687d6f912f	62c19d2c-eaa8-4d06-84d0-b02153132768	Beverages	4	t	2026-02-06 03:10:41.117769	0.00	\N
51651cfd-2bc2-482d-ac16-1ceb1bae2e91	62c19d2c-eaa8-4d06-84d0-b02153132768	Desserts	5	t	2026-02-06 03:10:41.118898	0.00	\N
1564c29f-a0e4-4314-8cf9-c7a134e6d7a5	62c19d2c-eaa8-4d06-84d0-b02153132768	Snacks	6	t	2026-02-06 03:10:41.120046	0.00	\N
2650d101-fd74-4293-b391-58566eaa27cf	62c19d2c-eaa8-4d06-84d0-b02153132768	Combo Meals	7	t	2026-02-06 03:10:41.121112	0.00	\N
\.


--
-- Data for Name: menu_items; Type: TABLE DATA; Schema: public; Owner: hdos
--

COPY public.menu_items (id, shop_id, category_id, name, description, price, image, is_available, is_veg, is_bestseller, created_at, updated_at) FROM stdin;
6973e317-6a09-429f-8540-641236da763a	abb2d289-d13b-4a97-b73f-b4f63161c766	f8a07de2-bd38-4dc5-ae18-d38c3a1c6a45	help	iaa11	9.00	\N	t	f	f	2026-02-06 01:44:52.762694	2026-02-06 01:44:52.762694
5b97275c-a2cd-4473-987b-5605634f2521	dd3cce5c-df8e-41ef-af93-4212b1a03e83	\N	help	\N	30.00	\N	t	f	f	2026-02-06 02:43:36.743625	2026-02-06 02:43:36.743625
d21db8d7-3a58-43f8-a49b-9ab038043e19	62c19d2c-eaa8-4d06-84d0-b02153132768	\N	pizza	\N	10.00	\N	t	t	f	2026-02-06 03:13:10.187232	2026-02-06 03:13:10.187232
\.


--
-- Data for Name: offers; Type: TABLE DATA; Schema: public; Owner: hdos
--

COPY public.offers (id, shop_id, title, description, discount_type, discount_value, min_visits, min_order_amount, expiry_date, is_active, created_at) FROM stdin;
dabe7e2f-63fb-4cb3-83a4-b05faa832c51	dd3cce5c-df8e-41ef-af93-4212b1a03e83	selfi	agar app marwahi cloud kichne ke delever patnur ke sath apa	fixed	10.00	0	\N	2026-07-06 00:00:00	t	2026-02-07 00:10:52.271062
f6e8d0df-6544-47e0-9e40-401f767b84fd	62c19d2c-eaa8-4d06-84d0-b02153132768	selfi	selfi	percentage	10.00	0	\N	\N	t	2026-02-07 00:12:24.941993
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: hdos
--

COPY public.order_items (id, order_id, item_id, item_name, price, quantity) FROM stdin;
2084ec50-921b-4fdf-9c80-55838164b730	dbe9a910-fa74-4e8e-b08f-f9daf45d0721	6973e317-6a09-429f-8540-641236da763a	help	9.00	1
7c5fd65f-4c3a-463e-820c-d143c2615819	3310a600-f989-4bef-95a8-dac0a4417d03	6973e317-6a09-429f-8540-641236da763a	help	9.00	1
cd914019-e3e1-4304-bf7e-592538b6905f	d824d504-c10d-4057-801e-5e947bfac795	6973e317-6a09-429f-8540-641236da763a	help	9.00	1
ab08f9aa-51b5-4bc8-b815-2193bc02dd28	bc6dcc7d-8b02-44ac-bc95-c57d07c8a1fc	d21db8d7-3a58-43f8-a49b-9ab038043e19	pizza	10.00	1
9f53cc1d-99e5-4925-818a-244e22ccf3bd	f1614273-1df9-4595-9fed-00099df9a3d5	d21db8d7-3a58-43f8-a49b-9ab038043e19	pizza	10.00	1
5bc4b68d-a3b9-4212-87a8-9817708e5f4b	af89e9dd-83ca-4531-988a-73b6c66eb414	d21db8d7-3a58-43f8-a49b-9ab038043e19	pizza	10.00	1
eaacc918-eb87-4ac8-a735-a1f4a7412009	e5cb85b5-cc2f-480b-9e7d-5c69d6ece5b0	d21db8d7-3a58-43f8-a49b-9ab038043e19	pizza	10.00	1
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: hdos
--

COPY public.orders (id, shop_id, customer_id, order_number, table_qr, delivery_address, subtotal, discount_amount, delivery_charge, total_amount, status, payment_mode, payment_reference, payment_verified_at, payment_verified_by, bill_number, bill_url, notes, created_at, updated_at) FROM stdin;
dbe9a910-fa74-4e8e-b08f-f9daf45d0721	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	\N	\N	marwahi, Pin Code: 495118	9.00	0.00	0.00	9.00	pending_payment	\N	\N	\N	\N	\N	\N	\N	2026-02-06 01:57:31.621306	2026-02-06 01:57:31.621306
3310a600-f989-4bef-95a8-dac0a4417d03	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	\N	\N	marwahi, Pin Code: 495118	9.00	0.00	0.00	9.00	pending_payment	\N	\N	\N	\N	\N	\N	\N	2026-02-06 02:15:32.00854	2026-02-06 02:15:32.00854
d824d504-c10d-4057-801e-5e947bfac795	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	\N	\N	marwahi, Pin Code: 495118	9.00	0.00	0.00	9.00	pending_payment	\N	\N	\N	\N	\N	\N	\N	2026-02-06 02:22:34.569565	2026-02-06 02:22:34.569565
bc6dcc7d-8b02-44ac-bc95-c57d07c8a1fc	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	\N	\N	Pin Code: 495118	10.00	0.00	10.00	20.00	pending_payment	\N	\N	\N	\N	\N	\N	\N	2026-02-06 03:34:44.976982	2026-02-06 03:34:44.976982
f1614273-1df9-4595-9fed-00099df9a3d5	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	\N	\N	garm dhanaura post parasi cg, Pin Code: 495118	10.00	0.00	10.00	20.00	pending_payment	\N	\N	\N	\N	\N	\N	\N	2026-02-06 03:37:08.080047	2026-02-06 03:37:08.080047
af89e9dd-83ca-4531-988a-73b6c66eb414	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	\N	\N	gram dhanaur, Pin Code: 495118	10.00	0.00	10.00	20.00	pending_payment	\N	\N	\N	\N	\N	\N	\N	2026-02-06 23:30:47.759081	2026-02-06 23:30:47.759081
e5cb85b5-cc2f-480b-9e7d-5c69d6ece5b0	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	\N	\N	gram dhanaur, Pin Code: 495118	10.00	0.00	10.00	20.00	pending_payment	\N	\N	\N	\N	\N	\N	\N	2026-02-06 23:33:31.978867	2026-02-06 23:33:31.978867
\.


--
-- Data for Name: page_visits; Type: TABLE DATA; Schema: public; Owner: hdos
--

COPY public.page_visits (id, page, shop_id, os, browser, device_type, user_agent, ip_hash, city, visited_at) FROM stdin;
0b0a7f36-fd6a-476d-adef-4be0d9dd6ac6	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 01:43:34.287306
8b64bb5e-32f8-4e90-b079-b7cc6a7c019e	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 01:45:10.168767
ee5fc931-8f27-473b-965b-a3b5c7a1978c	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 01:54:34.017662
45660a92-1adb-40f0-b679-cd23448a1277	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 01:56:42.124977
2ce8a67c-3ee6-4746-9d81-06e49e43256f	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 01:56:50.922439
1ae54bc1-2ce3-493e-b6eb-d000536ce4b5	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 01:59:03.12979
2a7f51c1-535a-470a-bac9-69512651bf7e	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 01:59:48.999424
ce7fa329-c7f1-41a1-a27a-2e9e8444ba20	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 02:13:50.986019
64bc91a7-56a4-44be-abde-59a8142d6d3a	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 02:14:38.335543
3f2bd1c5-5e8c-4d69-90f8-db69db541a15	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 02:14:49.133913
415368c9-7d2d-4fb2-a991-738dfc473c75	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 02:15:58.834382
eeee040a-c25c-4a6a-a700-91bb01fa31db	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 02:17:27.977851
6240dd63-0d20-4c88-a94f-aa50dffbc6d9	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 02:19:11.413645
4881d1eb-d5fe-4412-b090-73d05fa3d5f5	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 02:19:19.64739
67c35a95-d376-4207-b115-94fe51ca49e6	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 02:20:35.262267
e33b967c-121b-41ec-8567-198ab810f314	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 02:39:01.723948
22852692-762f-4325-a251-233cf25a5598	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 02:39:07.866136
5f291b56-642c-459b-adae-85c76d60b396	/s/miss	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 02:44:10.690442
0d0a1057-9e65-4270-b70b-80f20c9b291a	/s/miss	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 02:45:43.490495
f9f678eb-cc32-4154-84fc-ff6949abdaf4	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:05:09.50202
c42fbf9e-2e79-49f2-94eb-7202e90a701a	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:05:09.535985
98827c8d-b26c-463f-9955-a6b4d46c11be	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:05:09.57331
8d5df60b-d03f-49ed-87fb-bf04e2af425c	/s/miss	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:05:09.643225
1d425aac-19a7-4d6a-998d-5b5a9ba8ce91	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:05:21.822414
11ceed77-29c8-4a86-8af3-35269ae833c7	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:05:21.969154
d8f2bcdf-0520-4e42-b7f4-0841b3d5ff89	/s/miss	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:05:22.41552
23068647-29db-428c-b610-7c7bdaa72dc6	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:05:22.601178
d0fa5cc4-6a98-4f6a-9480-93632c0a15b7	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:05:35.880347
8e09adc1-8b95-4d91-b263-ce9b131621e8	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:05:36.003238
26e57556-19e7-4d04-b4fc-90ace324625a	/s/miss	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:05:36.187885
24842fbf-4685-4f3d-9cf2-f516f8e599f5	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:05:36.84409
431b80ed-f526-4a8d-879a-81c8561f21cc	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:13:22.457934
960c845a-ff05-4abd-b4d1-56e433a42931	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:13:59.859438
3f8022ce-feca-4fd2-9411-45ea6ac700c8	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:19:21.342435
49a57f73-8fa6-4d67-8d62-8892b846f034	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:19:26.26619
4633b5b5-6305-45e9-a160-f37550474f97	/s/miss	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:19:26.708684
48057a2e-e798-43fe-9ecf-5bdc6e3f301b	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:19:31.909255
2807a098-b332-4c83-80b0-647df2609b6a	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:19:32.427149
1be48d89-f8f1-4510-922a-9f52b0e1a938	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:19:32.899547
384217f3-1e2e-4f2b-b556-a9024867711b	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:19:35.02829
360ec10b-e75c-4a81-b132-b0d10784f3d6	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:19:56.143208
32e36b0a-9747-44ef-8613-e23f1cbbf397	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:23:04.600955
28a38f43-041b-46cd-ae84-e1ae17b7c705	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:26:32.016872
4a84ae37-5618-4895-95f8-25e5d7bd40d6	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:26:32.056917
57f5bb3a-b203-4acf-a70c-1f860a160be8	/s/miss	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:26:32.108849
a93740ca-203b-4b26-93de-08921c1f2130	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:26:32.170209
fb42f295-8837-4ca8-ba0c-f367555022c7	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:26:32.211412
82ee1bc4-9e6b-4ba1-90ce-12ef2f8a8097	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:26:56.571925
08e3415e-d51a-451f-9997-894aa4306aa8	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:26:56.834902
0a32254b-c30c-4be9-8e7e-cc5e5c73b298	/s/miss	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:26:57.009627
f3c5d046-00f1-450b-85ce-0b717be97dec	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:26:57.072735
154ae8be-a01e-4294-ad60-40ff4f40e9e8	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:26:57.204717
8c6587f6-e79a-4b94-90a9-277c9fe1d32d	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:29:08.203134
9e8bea20-194c-4ce8-b621-4ef93f1d226b	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:29:13.972101
dd0b90e8-6982-443d-b4c7-cc2a8412bb4a	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:29:56.530977
54ed8a7a-2979-4484-8ccc-53a4e8736d0e	/s/miss	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:35:02.259055
fac1d9a4-5356-42e5-a00e-fb730a410355	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:35:02.978676
344ffed9-9dc5-4886-baf5-ee538d2e5739	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:35:03.101574
957a1eb8-20d8-499a-b1b7-76130d84c775	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:35:03.414804
d83a36d3-91b5-412a-b09b-c4f25fc98771	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:35:03.443215
598d4e1c-8903-4052-8350-3ac8911def8f	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:35:03.555904
92f9a88d-07b6-43c9-b81a-55b65559209b	/s/miss	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:35:10.60162
f3785fbc-f9c2-413e-bc45-ae6475d8775a	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:35:10.763304
dda51eb0-75f0-4064-a8d4-47aeddd20e91	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:35:11.370208
1a97a989-274e-4f38-b5f4-328ef46206b8	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:35:11.459961
2a5d0ced-3044-4b8d-9fff-f7069c86d78a	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:35:11.729952
8c7d2207-5273-4ae9-88b3-a3621798ab2d	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:35:12.047196
f2f65d30-47d6-404e-a0c5-e70196e51be0	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:35:29.033907
31dc1e7b-187b-489d-9509-19921df93e2d	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:35:29.032834
0c9a7dca-fe0a-4d1e-824e-5834fb7b0b59	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:35:29.047546
b2b04655-3dab-406e-9c70-776844ceef95	/s/lalu	abb2d289-d13b-4a97-b73f-b4f63161c766	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:35:29.054031
87961996-a4fb-4c11-a44e-e2b35158f8e7	/s/miss	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:35:29.060335
ad7e3788-ea4d-4d4e-8052-b8f32c586b26	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:35:29.061812
dc4d098a-9653-4575-8154-b580c2f7db95	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:36:18.246153
acebfd68-b4ac-46f0-b32b-e72fe5f0c8cc	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	1dad44a39c027b8e	\N	2026-02-06 03:36:23.808239
d0a131be-5cca-4253-863f-3ffdecda3f8a	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	a7c51c36b7c0c061	\N	2026-02-06 22:50:22.711699
fedda1db-6bf9-4c51-9b56-a906e9d7268c	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	a7c51c36b7c0c061	\N	2026-02-06 22:50:46.421082
7805c43c-cff6-4f20-a96f-5b05d51f788c	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Linux	Chrome	Mobile	Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-G973U) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/14.2 Chrome/87.0.4280.141 Mobile Safari/537.36	a7c51c36b7c0c061	\N	2026-02-06 23:07:18.910101
34a6bda2-062a-4495-b573-e7f6c48aa52a	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Linux	Chrome	Mobile	Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-G973U) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/14.2 Chrome/87.0.4280.141 Mobile Safari/537.36	a7c51c36b7c0c061	\N	2026-02-06 23:07:39.860756
a1985dd3-b2da-4f46-97f5-2509b6779775	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Linux	Chrome	Mobile	Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-G973U) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/14.2 Chrome/87.0.4280.141 Mobile Safari/537.36	a7c51c36b7c0c061	\N	2026-02-06 23:10:20.569702
0f85a85c-abc4-48dc-bce4-6a22b1837a66	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Linux	Chrome	Mobile	Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-G973U) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/14.2 Chrome/87.0.4280.141 Mobile Safari/537.36	a7c51c36b7c0c061	\N	2026-02-06 23:10:34.617839
24ac009d-fe9b-4599-85b0-e6df916d4de1	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	a7c51c36b7c0c061	\N	2026-02-06 23:30:18.495158
2f18894b-ac05-496c-a8bd-b668eb1418e1	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	a7c51c36b7c0c061	\N	2026-02-06 23:30:23.242298
75b0d178-50e9-4a58-88c7-c22aa08b1aa2	/	\N	Linux	Chrome	Mobile	Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-G973U) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/14.2 Chrome/87.0.4280.141 Mobile Safari/537.36	a7c51c36b7c0c061	\N	2026-02-06 23:35:21.37541
4fedb442-5d52-4b0d-8ead-0cedae7d052a	/	\N	Linux	Chrome	Mobile	Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-G973U) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/14.2 Chrome/87.0.4280.141 Mobile Safari/537.36	a7c51c36b7c0c061	\N	2026-02-06 23:39:41.01442
4339e407-aa74-42b3-8d6a-41f1d2ffc87b	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	a9169ec63fc37cc9	\N	2026-02-07 00:04:23.506747
60790bef-632a-4570-82c6-abdeeb1969f1	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	a9169ec63fc37cc9	\N	2026-02-07 00:07:46.887011
9b72c9a4-5dc5-463d-a125-15479e533716	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	a9169ec63fc37cc9	\N	2026-02-07 00:07:54.838036
35bb12b7-d246-43fb-b7f3-6d90b2898eb8	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	a9169ec63fc37cc9	\N	2026-02-07 00:07:55.402424
20eef7d1-52b6-41a1-8b15-9ac4a178687c	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	a9169ec63fc37cc9	\N	2026-02-07 00:11:04.768433
d603298a-0c81-49d8-bad5-7d6c9e0e433a	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	a9169ec63fc37cc9	\N	2026-02-07 00:11:16.658372
2ac267a9-5a60-4ad0-9661-5f3ee63d7bb1	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	a9169ec63fc37cc9	\N	2026-02-07 00:11:23.782134
46bf0aa4-8a99-47c2-a2bd-e794f6370b41	/s/miss	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	a9169ec63fc37cc9	\N	2026-02-07 00:11:33.447271
a495b2c5-6844-4c05-b059-04cd55a1a2a4	/s/miss	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	a9169ec63fc37cc9	\N	2026-02-07 00:12:30.723021
58241ab2-6224-438b-94eb-a4263fac6b07	/s/manu	62c19d2c-eaa8-4d06-84d0-b02153132768	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	a9169ec63fc37cc9	\N	2026-02-07 00:12:56.811952
4fd5ff66-6257-48f6-8d4e-db5a7f5e33da	/	\N	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	e99b68d2f3e6f52b	\N	2026-02-07 07:47:30.686248
cbf8b681-4a2a-43ca-aef1-f03cec0d4585	/s/miss	dd3cce5c-df8e-41ef-af93-4212b1a03e83	Windows	Firefox	Desktop	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0	e99b68d2f3e6f52b	\N	2026-02-07 07:47:43.774784
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: hdos
--

COPY public.profiles (id, user_id, role, shop_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: hdos
--

COPY public.sessions (sid, sess, expire) FROM stdin;
PqTPM6yH0Pe_vEfWwBT_l9tqusWzSVBf	{"auth": {"role": "super_admin"}, "cookie": {"path": "/", "secure": false, "expires": "2026-02-08T00:08:08.224Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 86400000}}	2026-02-08 07:47:44
\.


--
-- Data for Name: shop_sections; Type: TABLE DATA; Schema: public; Owner: hdos
--

COPY public.shop_sections (id, shop_id, section_type, title, description, image_url, order_no, is_visible, settings, created_at) FROM stdin;
7563303d-8e18-47b4-8fe3-d42a783db8f0	abb2d289-d13b-4a97-b73f-b4f63161c766	hero	Welcome	\N	\N	0	t	\N	2026-02-06 01:43:58.161111
7bf5b53a-4ae4-44bb-9db4-d25c8112b912	abb2d289-d13b-4a97-b73f-b4f63161c766	menu	Our Menu	\N	\N	1	t	\N	2026-02-06 01:43:58.163263
5dcfdcee-85f7-40dd-b240-0886b21c4d8a	abb2d289-d13b-4a97-b73f-b4f63161c766	offers	Special Offers	\N	\N	2	t	\N	2026-02-06 01:43:58.164679
3cc8723d-24d8-4e27-8556-95f1974d5d42	abb2d289-d13b-4a97-b73f-b4f63161c766	whatsapp	Contact Us	\N	\N	3	t	\N	2026-02-06 01:43:58.165958
a856af39-c798-48ea-bffc-e7fb2dec6d9d	dd3cce5c-df8e-41ef-af93-4212b1a03e83	hero	Welcome	\N	\N	0	t	\N	2026-02-06 02:41:16.906917
1e7ffccd-9bea-42ee-884e-33569c7ef922	dd3cce5c-df8e-41ef-af93-4212b1a03e83	menu	Our Menu	\N	\N	1	t	\N	2026-02-06 02:41:16.909038
2f6f7cd7-4559-46ac-b3fe-bef7edd83518	dd3cce5c-df8e-41ef-af93-4212b1a03e83	offers	Special Offers	\N	\N	2	t	\N	2026-02-06 02:41:16.910279
0baf4287-ca24-48f9-90a6-be3c75d1fe4a	dd3cce5c-df8e-41ef-af93-4212b1a03e83	whatsapp	Contact Us	\N	\N	3	t	\N	2026-02-06 02:41:16.911589
a436e253-0a93-4df7-8a40-16de7ae14637	62c19d2c-eaa8-4d06-84d0-b02153132768	hero	Welcome	\N	\N	0	t	\N	2026-02-06 03:10:41.106674
b45f656c-0332-4328-81f7-59673399f3e7	62c19d2c-eaa8-4d06-84d0-b02153132768	menu	Our Menu	\N	\N	1	t	\N	2026-02-06 03:10:41.108536
5100ff95-37f0-4cbe-84dd-3a2af028c2ab	62c19d2c-eaa8-4d06-84d0-b02153132768	offers	Special Offers	\N	\N	2	t	\N	2026-02-06 03:10:41.109761
929c6186-330b-4caa-a32a-35e1dc78ef56	62c19d2c-eaa8-4d06-84d0-b02153132768	whatsapp	Contact Us	\N	\N	3	t	\N	2026-02-06 03:10:41.110995
\.


--
-- Data for Name: shop_themes; Type: TABLE DATA; Schema: public; Owner: hdos
--

COPY public.shop_themes (id, name, primary_color, secondary_color, font_family, button_style, created_at) FROM stdin;
\.


--
-- Data for Name: shops; Type: TABLE DATA; Schema: public; Owner: hdos
--

COPY public.shops (id, slug, shop_name, logo, banner, whatsapp_number, super_admin_whatsapp, address, about, theme_id, admin_password, upi_id, upi_qr_image, gst_number, delivery_charge, allowed_pin_codes, is_active, created_at, updated_at, delivery_charge_reason, free_delivery_threshold) FROM stdin;
abb2d289-d13b-4a97-b73f-b4f63161c766	lalu	lalu	\N	\N	\N	\N	marwahi	\N	\N	Shopln6hls	\N	\N	\N	0.00	495118	t	2026-02-06 01:43:58.156341	2026-02-06 01:43:58.156341	\N	\N
dd3cce5c-df8e-41ef-af93-4212b1a03e83	miss	miss	\N	\N	\N	\N	marwahi	\N	\N	Shopg0we67	\N	\N	\N	10.00	495118	t	2026-02-06 02:41:16.90474	2026-02-06 02:42:38.448	\N	\N
62c19d2c-eaa8-4d06-84d0-b02153132768	manu	manu	\N	\N	\N	\N	\N	\N	\N	Shop2l6vv1	\N	\N	\N	10.00	495118	t	2026-02-06 03:10:41.104708	2026-02-06 03:21:57.717	kilomeeter ke hisab se	100.00
\.


--
-- Data for Name: store_availability; Type: TABLE DATA; Schema: public; Owner: hdos
--

COPY public.store_availability (id, shop_id, opening_time, closing_time, timezone, manual_override, override_reason, created_at, updated_at) FROM stdin;
392419e5-eb57-4418-9ba5-c3bf40081c48	dd3cce5c-df8e-41ef-af93-4212b1a03e83	08:00	22:00	Asia/Kolkata	none	\N	2026-02-06 02:45:29.28249	2026-02-06 02:45:29.28249
35d91dd1-d3ee-4971-9f12-d45be6ccb7cd	abb2d289-d13b-4a97-b73f-b4f63161c766	08:00	22:00	Asia/Kolkata	none	\N	2026-02-06 01:56:31.752848	2026-02-06 02:45:29.284
76d539e1-1a47-4590-b0a7-3ead9f658177	62c19d2c-eaa8-4d06-84d0-b02153132768	09:00	22:00	Asia/Kolkata	force_open	Opened by Super Admin	2026-02-06 03:13:50.722042	2026-02-06 03:13:50.722042
\.


--
-- Data for Name: store_holidays; Type: TABLE DATA; Schema: public; Owner: hdos
--

COPY public.store_holidays (id, shop_id, holiday_date, name, created_at) FROM stdin;
eb5de9a3-0000-469e-94c5-e824570fa506	abb2d289-d13b-4a97-b73f-b4f63161c766	2026-02-06	masti	2026-02-06 01:58:55.144221
\.


--
-- Data for Name: user_behaviors; Type: TABLE DATA; Schema: public; Owner: hdos
--

COPY public.user_behaviors (id, shop_id, customer_id, session_id, event_type, item_id, page, time_spent, metadata, occurred_at) FROM stdin;
ab9c9cf1-4baa-4be4-a3f8-94c9a1370a29	abb2d289-d13b-4a97-b73f-b4f63161c766	\N	52ee9eab-818f-4807-a0d5-186eb01ca3a2	page_view	\N	/s/lalu	\N	{"page": "shop"}	2026-02-06 01:45:10.347009
30a1be37-4eca-4734-88cd-ac332f0f2155	abb2d289-d13b-4a97-b73f-b4f63161c766	\N	52ee9eab-818f-4807-a0d5-186eb01ca3a2	add_to_cart	\N	/s/lalu	\N	{"price": "9.00", "itemId": "6973e317-6a09-429f-8540-641236da763a", "itemName": "help"}	2026-02-06 01:45:23.073161
c024f5c4-f1b8-4745-8c70-d95b26e975f1	abb2d289-d13b-4a97-b73f-b4f63161c766	\N	52ee9eab-818f-4807-a0d5-186eb01ca3a2	item_view	\N	/s/lalu	\N	{"itemId": "6973e317-6a09-429f-8540-641236da763a", "itemName": "help"}	2026-02-06 01:50:28.449514
4512b9a9-e609-4021-9a2f-58940489a7f3	abb2d289-d13b-4a97-b73f-b4f63161c766	\N	52ee9eab-818f-4807-a0d5-186eb01ca3a2	page_view	\N	/s/lalu	\N	{"page": "shop"}	2026-02-06 01:56:51.500604
d6243e8b-23d9-45c9-bed7-532ac71f7529	abb2d289-d13b-4a97-b73f-b4f63161c766	\N	52ee9eab-818f-4807-a0d5-186eb01ca3a2	add_to_cart	\N	/s/lalu	\N	{"price": "9.00", "itemId": "6973e317-6a09-429f-8540-641236da763a", "itemName": "help"}	2026-02-06 01:56:55.753988
ef835ed0-0f9b-4a90-b1d3-9430cfecfc5c	abb2d289-d13b-4a97-b73f-b4f63161c766	\N	52ee9eab-818f-4807-a0d5-186eb01ca3a2	checkout_start	\N	/s/lalu	\N	{"total": 9, "itemCount": 1}	2026-02-06 01:57:31.605511
df0c963a-97a0-4657-9dff-d1bd4a830ce6	abb2d289-d13b-4a97-b73f-b4f63161c766	\N	52ee9eab-818f-4807-a0d5-186eb01ca3a2	order_placed	\N	/s/lalu	\N	{"total": 9, "orderId": "dbe9a910-fa74-4e8e-b08f-f9daf45d0721"}	2026-02-06 01:57:31.782642
08564b04-5801-4b1e-87a1-c8b60b42599f	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	page_view	\N	/s/lalu	\N	{"page": "shop"}	2026-02-06 01:59:03.171972
9e2c796c-e954-4be8-82b1-fdd7845dcc73	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	page_view	\N	/s/lalu	\N	{"page": "shop"}	2026-02-06 02:14:49.15844
bb65d876-d0a9-44c7-a60b-1502ac4ad629	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	item_view	\N	/s/lalu	\N	{"itemId": "6973e317-6a09-429f-8540-641236da763a", "itemName": "help"}	2026-02-06 02:14:53.003738
7de889a6-c4d9-484f-a187-6b93024d2c6f	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	add_to_cart	\N	/s/lalu	\N	{"price": "9.00", "itemId": "6973e317-6a09-429f-8540-641236da763a", "itemName": "help"}	2026-02-06 02:15:10.104448
9b2817ba-e9a7-4916-bc30-e9666fc54384	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	checkout_start	\N	/s/lalu	\N	{"total": 9, "itemCount": 1}	2026-02-06 02:15:31.963185
96acf5f7-1f65-42c6-89f2-f623dbd2cc80	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	order_placed	\N	/s/lalu	\N	{"total": 9, "orderId": "3310a600-f989-4bef-95a8-dac0a4417d03"}	2026-02-06 02:15:32.227804
d635fc3e-2370-42ab-aac8-1d5b42d243f2	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	page_view	\N	/s/lalu	\N	{"page": "shop"}	2026-02-06 02:15:58.838593
16c4f0a4-a079-4d59-8101-3281fe8486f7	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	page_view	\N	/s/lalu	\N	{"page": "shop"}	2026-02-06 02:17:28.000236
8c33297d-90f2-4679-9daa-69537f2179b9	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	page_view	\N	/s/lalu	\N	{"page": "shop"}	2026-02-06 02:19:11.475048
93d3a0ec-79f0-4ff4-84d6-54159fc25cba	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	page_view	\N	/s/lalu	\N	{"page": "shop"}	2026-02-06 02:19:19.667412
7f31d18a-6795-41df-809f-f0765ad5bdef	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	page_view	\N	/s/lalu	\N	{"page": "shop"}	2026-02-06 02:20:35.29032
df253cc0-efda-4a2b-ba1b-c54bcbe421f2	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	add_to_cart	\N	/s/lalu	\N	{"price": "9.00", "itemId": "6973e317-6a09-429f-8540-641236da763a", "itemName": "help"}	2026-02-06 02:20:38.695175
71d36bf7-eadf-49b8-a217-dbfcdc9c2df8	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	checkout_start	\N	/s/lalu	\N	{"total": 9, "itemCount": 1}	2026-02-06 02:22:34.56314
f64d37b1-2401-4a85-97e8-e225bd0f4ee6	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	order_placed	\N	/s/lalu	\N	{"total": 9, "orderId": "d824d504-c10d-4057-801e-5e947bfac795"}	2026-02-06 02:22:34.742336
d9f38506-fe0e-452c-ab55-242a6f96a0cf	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	page_view	\N	/s/lalu	\N	{"page": "shop"}	2026-02-06 02:39:07.906119
4e3581f5-12f7-4f76-8add-0a02ddb58a86	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	item_view	\N	/s/lalu	\N	{"itemId": "6973e317-6a09-429f-8540-641236da763a", "itemName": "help"}	2026-02-06 02:39:12.835249
0e884a9d-ab47-49fc-878d-f92ceb862db1	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	add_to_cart	\N	/s/lalu	\N	{"price": "9.00", "itemId": "6973e317-6a09-429f-8540-641236da763a", "itemName": "help"}	2026-02-06 02:39:14.053022
8afff968-52d8-4458-95ba-a613331156b0	dd3cce5c-df8e-41ef-af93-4212b1a03e83	\N	a806f239-9ae2-4bd8-93bd-7d66f8fb04b6	page_view	\N	/s/miss	\N	{"page": "shop"}	2026-02-06 02:44:11.037428
4461391a-af97-4644-985f-71d1843e67a3	dd3cce5c-df8e-41ef-af93-4212b1a03e83	\N	a806f239-9ae2-4bd8-93bd-7d66f8fb04b6	add_to_cart	\N	/s/miss	\N	{"price": "30.00", "itemId": "5b97275c-a2cd-4473-987b-5605634f2521", "itemName": "help"}	2026-02-06 02:44:18.872919
343fb625-6445-4ee3-bd5f-2561b44c9b2c	dd3cce5c-df8e-41ef-af93-4212b1a03e83	\N	a806f239-9ae2-4bd8-93bd-7d66f8fb04b6	page_view	\N	/s/miss	\N	{"page": "shop"}	2026-02-06 02:45:43.55186
23b2ee08-4937-43ad-a995-9590a9118995	dd3cce5c-df8e-41ef-af93-4212b1a03e83	\N	a806f239-9ae2-4bd8-93bd-7d66f8fb04b6	add_to_cart	\N	/s/miss	\N	{"price": "30.00", "itemId": "5b97275c-a2cd-4473-987b-5605634f2521", "itemName": "help"}	2026-02-06 02:45:48.434135
76f3c272-0ebc-4ee1-8bf4-a469483d49c9	62c19d2c-eaa8-4d06-84d0-b02153132768	\N	16f90ba7-66de-41e8-a6be-da3905ecfb83	page_view	\N	/s/manu	\N	{"page": "shop"}	2026-02-06 03:13:22.784813
8ff1607a-d569-4d5b-9a6d-25d15d0fe249	62c19d2c-eaa8-4d06-84d0-b02153132768	\N	16f90ba7-66de-41e8-a6be-da3905ecfb83	page_view	\N	/s/manu	\N	{"page": "shop"}	2026-02-06 03:13:59.910119
ef85df7e-8270-4de8-bb32-cde4c3f7ba74	62c19d2c-eaa8-4d06-84d0-b02153132768	\N	16f90ba7-66de-41e8-a6be-da3905ecfb83	add_to_cart	\N	/s/manu	\N	{"price": "10.00", "itemId": "d21db8d7-3a58-43f8-a49b-9ab038043e19", "itemName": "pizza"}	2026-02-06 03:14:04.289268
e3453cb2-282b-4238-9269-dedf216e9ed9	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	page_view	\N	/s/lalu	\N	{"page": "shop"}	2026-02-06 03:19:26.289212
37731e42-06da-4ce2-b9fb-cb6c65f5f33c	dd3cce5c-df8e-41ef-af93-4212b1a03e83	\N	a806f239-9ae2-4bd8-93bd-7d66f8fb04b6	page_view	\N	/s/miss	\N	{"page": "shop"}	2026-02-06 03:19:26.746186
ee1732e2-bfc4-46fa-9b71-6506e1836b7d	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	page_view	\N	/s/lalu	\N	{"page": "shop"}	2026-02-06 03:19:31.918233
53ea36fa-5d9e-40b2-a379-125b93d30b7e	62c19d2c-eaa8-4d06-84d0-b02153132768	\N	16f90ba7-66de-41e8-a6be-da3905ecfb83	page_view	\N	/s/manu	\N	{"page": "shop"}	2026-02-06 03:19:32.43814
aea15be0-bb18-4b37-974b-dd766ac7abdc	62c19d2c-eaa8-4d06-84d0-b02153132768	\N	16f90ba7-66de-41e8-a6be-da3905ecfb83	page_view	\N	/s/manu	\N	{"page": "shop"}	2026-02-06 03:19:32.910986
321b9f26-11cd-4cbd-9940-6d1ff70ad30e	abb2d289-d13b-4a97-b73f-b4f63161c766	191f8706-bae1-407c-917b-6040c1dd17a2	52ee9eab-818f-4807-a0d5-186eb01ca3a2	page_view	\N	/s/lalu	\N	{"page": "shop"}	2026-02-06 03:19:35.029548
243d966c-7267-4e3f-a6ac-6eafef8fbc7a	62c19d2c-eaa8-4d06-84d0-b02153132768	\N	16f90ba7-66de-41e8-a6be-da3905ecfb83	add_to_cart	\N	/s/manu	\N	{"price": "10.00", "itemId": "d21db8d7-3a58-43f8-a49b-9ab038043e19", "itemName": "pizza"}	2026-02-06 03:19:36.777764
161c870b-d440-42fe-9936-e06a75fe2505	62c19d2c-eaa8-4d06-84d0-b02153132768	\N	16f90ba7-66de-41e8-a6be-da3905ecfb83	page_view	\N	/s/manu	\N	{"page": "shop"}	2026-02-06 03:23:04.621065
b645d350-1b07-467f-931e-361250f9d13d	62c19d2c-eaa8-4d06-84d0-b02153132768	\N	16f90ba7-66de-41e8-a6be-da3905ecfb83	add_to_cart	\N	/s/manu	\N	{"price": "10.00", "itemId": "d21db8d7-3a58-43f8-a49b-9ab038043e19", "itemName": "pizza"}	2026-02-06 03:23:09.985191
f0a889b8-d0d2-4b86-88d9-fd70b1a8e41e	62c19d2c-eaa8-4d06-84d0-b02153132768	\N	16f90ba7-66de-41e8-a6be-da3905ecfb83	page_view	\N	/s/manu	\N	{"page": "shop"}	2026-02-06 03:29:13.98933
0749caf7-aea1-4293-816a-fb156f3f77b4	62c19d2c-eaa8-4d06-84d0-b02153132768	\N	16f90ba7-66de-41e8-a6be-da3905ecfb83	add_to_cart	\N	/s/manu	\N	{"price": "10.00", "itemId": "d21db8d7-3a58-43f8-a49b-9ab038043e19", "itemName": "pizza"}	2026-02-06 03:29:18.570795
0cbb93c8-6f78-42ff-af6c-c5002081a1a9	62c19d2c-eaa8-4d06-84d0-b02153132768	\N	16f90ba7-66de-41e8-a6be-da3905ecfb83	page_view	\N	/s/manu	\N	{"page": "shop"}	2026-02-06 03:29:56.639171
e30fc130-f477-46e0-ae80-dbfc73c7ac1a	62c19d2c-eaa8-4d06-84d0-b02153132768	\N	16f90ba7-66de-41e8-a6be-da3905ecfb83	add_to_cart	\N	/s/manu	\N	{"price": "10.00", "itemId": "d21db8d7-3a58-43f8-a49b-9ab038043e19", "itemName": "pizza"}	2026-02-06 03:30:16.741162
0223796b-930a-4225-a996-5932af2dcd75	62c19d2c-eaa8-4d06-84d0-b02153132768	\N	16f90ba7-66de-41e8-a6be-da3905ecfb83	checkout_start	\N	/s/manu	\N	{"total": 20, "itemCount": 1}	2026-02-06 03:34:44.973952
3df99ed9-fb9a-404e-a3c2-7dd7031d284c	62c19d2c-eaa8-4d06-84d0-b02153132768	\N	16f90ba7-66de-41e8-a6be-da3905ecfb83	order_placed	\N	/s/manu	\N	{"total": 20, "orderId": "bc6dcc7d-8b02-44ac-bc95-c57d07c8a1fc"}	2026-02-06 03:34:45.160666
473f785d-c4c2-4e52-9db4-bc7e9b619203	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	page_view	\N	/s/manu	\N	{"page": "shop"}	2026-02-06 03:36:23.843513
589476d4-fbce-4b73-ab29-244ecaab12b3	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	add_to_cart	\N	/s/manu	\N	{"price": "10.00", "itemId": "d21db8d7-3a58-43f8-a49b-9ab038043e19", "itemName": "pizza"}	2026-02-06 03:36:26.933437
e898b687-4103-4be4-ad07-763718f9ebf4	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	checkout_start	\N	/s/manu	\N	{"total": 20, "itemCount": 1}	2026-02-06 03:36:45.386705
8d6c2893-48f1-40c0-9e9d-6c353af09aaf	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	checkout_start	\N	/s/manu	\N	{"total": 20, "itemCount": 1}	2026-02-06 03:36:46.58892
25e0251a-937c-449d-8d66-c779411a957e	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	checkout_start	\N	/s/manu	\N	{"total": 20, "itemCount": 1}	2026-02-06 03:36:47.932661
48a26313-7e83-4bfe-8457-fa4b196cf80e	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	checkout_start	\N	/s/manu	\N	{"total": 20, "itemCount": 1}	2026-02-06 03:36:51.976662
b791104b-0292-4d02-b687-8e0f3cbf8c7b	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	checkout_start	\N	/s/manu	\N	{"total": 20, "itemCount": 1}	2026-02-06 03:37:08.064579
5f618919-cbe4-46f4-a986-d570dfe0f5b0	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	order_placed	\N	/s/manu	\N	{"total": 20, "orderId": "f1614273-1df9-4595-9fed-00099df9a3d5"}	2026-02-06 03:37:08.251106
271c23ed-cd1e-4800-9319-e6d5a6b839d6	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	page_view	\N	/s/manu	\N	{"page": "shop"}	2026-02-06 22:50:46.433812
f4996043-11df-4b7e-bbd0-e6a6337b5248	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	item_view	\N	/s/manu	\N	{"itemId": "d21db8d7-3a58-43f8-a49b-9ab038043e19", "itemName": "pizza"}	2026-02-06 22:50:51.083152
c5ca8d84-4215-4a70-b79c-cf32c0fe3acd	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	add_to_cart	\N	/s/manu	\N	{"price": "10.00", "itemId": "d21db8d7-3a58-43f8-a49b-9ab038043e19", "itemName": "pizza"}	2026-02-06 22:50:59.944618
d607edc9-0b6e-41ed-b3d0-0a39f428edb9	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	item_view	\N	/s/manu	\N	{"itemId": "d21db8d7-3a58-43f8-a49b-9ab038043e19", "itemName": "pizza"}	2026-02-06 22:52:05.76878
6307b1d1-967c-48c1-823b-a20e4b604ea0	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	item_view	\N	/s/manu	\N	{"itemId": "d21db8d7-3a58-43f8-a49b-9ab038043e19", "itemName": "pizza"}	2026-02-06 22:52:06.663072
f0d78b64-d7a6-458b-a192-3c7bbd0a39e7	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	item_view	\N	/s/manu	\N	{"itemId": "d21db8d7-3a58-43f8-a49b-9ab038043e19", "itemName": "pizza"}	2026-02-06 22:52:06.881554
aa5ca12f-1096-450b-ba8b-db17ad1d5ab6	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	page_view	\N	/s/manu	\N	{"page": "shop"}	2026-02-06 23:07:18.897464
9898558c-5dab-47f7-b60f-4454bf5d25fc	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	page_view	\N	/s/manu	\N	{"page": "shop"}	2026-02-06 23:07:39.867704
27b25000-4d78-462a-9e7b-95c0fc0e590a	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	page_view	\N	/s/manu	\N	{"page": "shop"}	2026-02-06 23:10:20.583575
aba7bdf5-9a50-4e20-b18f-95a473ce3df7	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	page_view	\N	/s/manu	\N	{"page": "shop"}	2026-02-06 23:10:34.638755
bd51bc37-6ed5-498a-9763-222d54aa1c29	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	page_view	\N	/s/manu	\N	{"page": "shop"}	2026-02-06 23:30:23.271511
cc0960f1-2721-4feb-9ca5-6bcc68ff49e3	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	add_to_cart	\N	/s/manu	\N	{"price": "10.00", "itemId": "d21db8d7-3a58-43f8-a49b-9ab038043e19", "itemName": "pizza"}	2026-02-06 23:30:27.069233
cf1c3129-0a7a-4a7a-9d95-13b5a03cd784	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	checkout_start	\N	/s/manu	\N	{"total": 20, "itemCount": 1}	2026-02-06 23:30:47.739246
509a0aac-81c6-4403-8dff-2dd427ce0e55	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	order_placed	\N	/s/manu	\N	{"total": 20, "orderId": "af89e9dd-83ca-4531-988a-73b6c66eb414"}	2026-02-06 23:30:47.94907
e7a52554-a350-4202-b300-47c1c517ca56	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	add_to_cart	\N	/s/manu	\N	{"price": "10.00", "itemId": "d21db8d7-3a58-43f8-a49b-9ab038043e19", "itemName": "pizza"}	2026-02-06 23:33:19.865745
f33ae18a-f573-41eb-abe2-d4f4d5254493	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	checkout_start	\N	/s/manu	\N	{"total": 20, "itemCount": 1}	2026-02-06 23:33:31.893315
b144f17a-2323-4fef-9d21-d3e499e1b72c	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	order_placed	\N	/s/manu	\N	{"total": 20, "orderId": "e5cb85b5-cc2f-480b-9e7d-5c69d6ece5b0"}	2026-02-06 23:33:32.192686
e5d944a7-702e-4e0d-9324-bf0d33f672fa	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	page_view	\N	/s/manu	\N	{"page": "shop"}	2026-02-07 00:07:54.86774
5f175f31-2dba-42d7-a5a7-54df5e5cf8b5	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	page_view	\N	/s/manu	\N	{"page": "shop"}	2026-02-07 00:11:16.69619
867835c5-76da-4b0b-b144-10bb831abebc	dd3cce5c-df8e-41ef-af93-4212b1a03e83	\N	a806f239-9ae2-4bd8-93bd-7d66f8fb04b6	page_view	\N	/s/miss	\N	{"page": "shop"}	2026-02-07 00:11:33.45734
76498d9a-e118-467e-8c66-daee469c9a17	dd3cce5c-df8e-41ef-af93-4212b1a03e83	\N	a806f239-9ae2-4bd8-93bd-7d66f8fb04b6	page_view	\N	/s/miss	\N	{"page": "shop"}	2026-02-07 00:12:30.734523
07494180-1030-4161-bf62-bbd174741116	62c19d2c-eaa8-4d06-84d0-b02153132768	01346c2d-367d-4e4d-9f48-49d5ad3ce29b	16f90ba7-66de-41e8-a6be-da3905ecfb83	page_view	\N	/s/manu	\N	{"page": "shop"}	2026-02-07 00:12:56.824831
c7dcde5a-d60c-4106-ac8c-3da9b567b59b	dd3cce5c-df8e-41ef-af93-4212b1a03e83	\N	a806f239-9ae2-4bd8-93bd-7d66f8fb04b6	page_view	\N	/s/miss	\N	{"page": "shop"}	2026-02-07 07:47:43.81238
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: hdos
--

COPY public.users (id, email, first_name, last_name, profile_image_url, created_at, updated_at) FROM stdin;
\.


--
-- Name: customer_sessions customer_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.customer_sessions
    ADD CONSTRAINT customer_sessions_pkey PRIMARY KEY (id);


--
-- Name: customer_sessions customer_sessions_session_token_unique; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.customer_sessions
    ADD CONSTRAINT customer_sessions_session_token_unique UNIQUE (session_token);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: delivery_charge_reasons delivery_charge_reasons_pkey; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.delivery_charge_reasons
    ADD CONSTRAINT delivery_charge_reasons_pkey PRIMARY KEY (id);


--
-- Name: menu_categories menu_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.menu_categories
    ADD CONSTRAINT menu_categories_pkey PRIMARY KEY (id);


--
-- Name: menu_items menu_items_pkey; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_pkey PRIMARY KEY (id);


--
-- Name: offers offers_pkey; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: page_visits page_visits_pkey; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.page_visits
    ADD CONSTRAINT page_visits_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (sid);


--
-- Name: shop_sections shop_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.shop_sections
    ADD CONSTRAINT shop_sections_pkey PRIMARY KEY (id);


--
-- Name: shop_themes shop_themes_pkey; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.shop_themes
    ADD CONSTRAINT shop_themes_pkey PRIMARY KEY (id);


--
-- Name: shops shops_pkey; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.shops
    ADD CONSTRAINT shops_pkey PRIMARY KEY (id);


--
-- Name: shops shops_slug_unique; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.shops
    ADD CONSTRAINT shops_slug_unique UNIQUE (slug);


--
-- Name: store_availability store_availability_pkey; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.store_availability
    ADD CONSTRAINT store_availability_pkey PRIMARY KEY (id);


--
-- Name: store_holidays store_holidays_pkey; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.store_holidays
    ADD CONSTRAINT store_holidays_pkey PRIMARY KEY (id);


--
-- Name: user_behaviors user_behaviors_pkey; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.user_behaviors
    ADD CONSTRAINT user_behaviors_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX "IDX_session_expire" ON public.sessions USING btree (expire);


--
-- Name: idx_behaviors_customer; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_behaviors_customer ON public.user_behaviors USING btree (customer_id);


--
-- Name: idx_behaviors_event; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_behaviors_event ON public.user_behaviors USING btree (event_type);


--
-- Name: idx_behaviors_occurred; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_behaviors_occurred ON public.user_behaviors USING btree (occurred_at);


--
-- Name: idx_behaviors_session; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_behaviors_session ON public.user_behaviors USING btree (session_id);


--
-- Name: idx_behaviors_shop; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_behaviors_shop ON public.user_behaviors USING btree (shop_id);


--
-- Name: idx_customers_phone; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_customers_phone ON public.customers USING btree (phone);


--
-- Name: idx_customers_shop; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_customers_shop ON public.customers USING btree (shop_id);


--
-- Name: idx_delivery_reasons_shop; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_delivery_reasons_shop ON public.delivery_charge_reasons USING btree (shop_id);


--
-- Name: idx_menu_categories_shop; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_menu_categories_shop ON public.menu_categories USING btree (shop_id);


--
-- Name: idx_menu_items_category; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_menu_items_category ON public.menu_items USING btree (category_id);


--
-- Name: idx_menu_items_shop; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_menu_items_shop ON public.menu_items USING btree (shop_id);


--
-- Name: idx_offers_shop; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_offers_shop ON public.offers USING btree (shop_id);


--
-- Name: idx_order_items_order; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_order_items_order ON public.order_items USING btree (order_id);


--
-- Name: idx_orders_created; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_orders_created ON public.orders USING btree (created_at);


--
-- Name: idx_orders_customer; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_orders_customer ON public.orders USING btree (customer_id);


--
-- Name: idx_orders_shop; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_orders_shop ON public.orders USING btree (shop_id);


--
-- Name: idx_orders_status; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_orders_status ON public.orders USING btree (status);


--
-- Name: idx_page_visits_page; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_page_visits_page ON public.page_visits USING btree (page);


--
-- Name: idx_page_visits_shop; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_page_visits_shop ON public.page_visits USING btree (shop_id);


--
-- Name: idx_page_visits_visited; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_page_visits_visited ON public.page_visits USING btree (visited_at);


--
-- Name: idx_profiles_shop; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_profiles_shop ON public.profiles USING btree (shop_id);


--
-- Name: idx_profiles_user; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_profiles_user ON public.profiles USING btree (user_id);


--
-- Name: idx_sessions_customer; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_sessions_customer ON public.customer_sessions USING btree (customer_id);


--
-- Name: idx_sessions_shop; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_sessions_shop ON public.customer_sessions USING btree (shop_id);


--
-- Name: idx_sessions_token; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_sessions_token ON public.customer_sessions USING btree (session_token);


--
-- Name: idx_shop_sections_shop; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_shop_sections_shop ON public.shop_sections USING btree (shop_id);


--
-- Name: idx_shops_slug; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_shops_slug ON public.shops USING btree (slug);


--
-- Name: idx_store_availability_shop; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_store_availability_shop ON public.store_availability USING btree (shop_id);


--
-- Name: idx_store_holidays_date; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_store_holidays_date ON public.store_holidays USING btree (holiday_date);


--
-- Name: idx_store_holidays_shop; Type: INDEX; Schema: public; Owner: hdos
--

CREATE INDEX idx_store_holidays_shop ON public.store_holidays USING btree (shop_id);


--
-- Name: customer_sessions customer_sessions_customer_id_customers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.customer_sessions
    ADD CONSTRAINT customer_sessions_customer_id_customers_id_fk FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: customer_sessions customer_sessions_shop_id_shops_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.customer_sessions
    ADD CONSTRAINT customer_sessions_shop_id_shops_id_fk FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON DELETE CASCADE;


--
-- Name: customers customers_shop_id_shops_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_shop_id_shops_id_fk FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON DELETE CASCADE;


--
-- Name: delivery_charge_reasons delivery_charge_reasons_shop_id_shops_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.delivery_charge_reasons
    ADD CONSTRAINT delivery_charge_reasons_shop_id_shops_id_fk FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON DELETE CASCADE;


--
-- Name: menu_categories menu_categories_shop_id_shops_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.menu_categories
    ADD CONSTRAINT menu_categories_shop_id_shops_id_fk FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON DELETE CASCADE;


--
-- Name: menu_items menu_items_category_id_menu_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_category_id_menu_categories_id_fk FOREIGN KEY (category_id) REFERENCES public.menu_categories(id) ON DELETE SET NULL;


--
-- Name: menu_items menu_items_shop_id_shops_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_shop_id_shops_id_fk FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON DELETE CASCADE;


--
-- Name: offers offers_shop_id_shops_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_shop_id_shops_id_fk FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_item_id_menu_items_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_item_id_menu_items_id_fk FOREIGN KEY (item_id) REFERENCES public.menu_items(id);


--
-- Name: order_items order_items_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: orders orders_customer_id_customers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_customers_id_fk FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: orders orders_shop_id_shops_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_shop_id_shops_id_fk FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON DELETE CASCADE;


--
-- Name: page_visits page_visits_shop_id_shops_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.page_visits
    ADD CONSTRAINT page_visits_shop_id_shops_id_fk FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON DELETE SET NULL;


--
-- Name: profiles profiles_shop_id_shops_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_shop_id_shops_id_fk FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON DELETE SET NULL;


--
-- Name: shop_sections shop_sections_shop_id_shops_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.shop_sections
    ADD CONSTRAINT shop_sections_shop_id_shops_id_fk FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON DELETE CASCADE;


--
-- Name: shops shops_theme_id_shop_themes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.shops
    ADD CONSTRAINT shops_theme_id_shop_themes_id_fk FOREIGN KEY (theme_id) REFERENCES public.shop_themes(id);


--
-- Name: store_availability store_availability_shop_id_shops_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.store_availability
    ADD CONSTRAINT store_availability_shop_id_shops_id_fk FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON DELETE CASCADE;


--
-- Name: store_holidays store_holidays_shop_id_shops_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.store_holidays
    ADD CONSTRAINT store_holidays_shop_id_shops_id_fk FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON DELETE CASCADE;


--
-- Name: user_behaviors user_behaviors_customer_id_customers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.user_behaviors
    ADD CONSTRAINT user_behaviors_customer_id_customers_id_fk FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: user_behaviors user_behaviors_item_id_menu_items_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.user_behaviors
    ADD CONSTRAINT user_behaviors_item_id_menu_items_id_fk FOREIGN KEY (item_id) REFERENCES public.menu_items(id) ON DELETE SET NULL;


--
-- Name: user_behaviors user_behaviors_session_id_customer_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.user_behaviors
    ADD CONSTRAINT user_behaviors_session_id_customer_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.customer_sessions(id) ON DELETE SET NULL;


--
-- Name: user_behaviors user_behaviors_shop_id_shops_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: hdos
--

ALTER TABLE ONLY public.user_behaviors
    ADD CONSTRAINT user_behaviors_shop_id_shops_id_fk FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict oZ5wb9b8GAK9I7iExRacf3phCgZLBNJKFi6zqs1wS1N3UxfKRFywTdxFUljjU7G

